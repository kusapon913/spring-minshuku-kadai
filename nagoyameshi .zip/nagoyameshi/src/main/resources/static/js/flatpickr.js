let maxDate = new Date();
 maxDate = maxDate.setMonth(maxDate.getMonth() + 3);
 
 flatpickr('#fromReservedDatetime', {
  enableTime: true,
dateFormat: "Y-m-d H:i",
 });