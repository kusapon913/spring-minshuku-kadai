package com.example.nagoyameshi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NagoyameshiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NagoyameshiApplication.class, args);
	}

}
