const stripe = Stripe('pk_test_51O9B4OBKIkMXmia6HLCVA7O4fGLimtDpXWthIrUECX30YycUVcRPwVFhnEO10N2rzwm6TSP0pJjmp433vDGvc6Ev001ZGoZiQc');
const paymentButton = document.querySelector('#paymentButton');

paymentButton.addEventListener('click', () => {
	stripe.redirectToCheckout({
		sessionId: sessionId
	})
});