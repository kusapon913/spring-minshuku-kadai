package com.example.demo.samuraitravel.entity;


public class VerificationToken {
	 

}
