package com.example.demo.samuraitravel.service;


public class VerificationTokenService {
	

}
