package com.example.demo.samuraitravel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.samuraitravel.entity.Role;

public interface RoleRepository extends JpaRepository<Role,Integer>{
	public Role findByName(String name);
}
