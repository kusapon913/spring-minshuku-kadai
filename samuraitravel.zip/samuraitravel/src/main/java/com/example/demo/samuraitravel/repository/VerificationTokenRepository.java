package com.example.demo.samuraitravel.repository;


public interface VerificationTokenRepository  {
    

}
