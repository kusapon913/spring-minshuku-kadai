package com.example.demo.samuraitravel.event;


public class SignupEvent  {
    

}
