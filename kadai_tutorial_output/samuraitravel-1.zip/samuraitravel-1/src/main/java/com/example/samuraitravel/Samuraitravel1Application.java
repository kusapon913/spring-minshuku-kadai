package com.example.samuraitravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Samuraitravel1Application {

	public static void main(String[] args) {
		SpringApplication.run(Samuraitravel1Application.class, args);
	}

}
